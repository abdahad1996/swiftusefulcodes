//
//  WeatherModel.swift
//  WeatherApp
//
//  Created by Gwinyai on 9/1/2019.
//  Copyright © 2019 Gwinyai Nyatsoka. All rights reserved.
//

import Foundation

struct MainWeather: Codable {
    
    var temp: String
    
    //var humidity: Double
    
}

class WeatherModel: NSObject, Codable {
    
    var name: String = ""
    
    //var main: MainWeather = MainWeather(temp: "0")
    
    var temp: Double = 0.0
    
    var humidity: Int = 0
    
    var windSpeed: Double = 0
    
    enum CodingKeys: String, CodingKey {
        
        case name
        
        case main = "main"
        
        case wind = "wind"
        
        case humidity
        
        case temp
        
        case speed
        
    }
    
    func encode(to encoder: Encoder) throws {
        
    }
    
    override init() {
        
    }
    
    convenience required init(from decoder: Decoder) throws {
        
        self.init()
        
        //let values = try decoder.container(keyedBy: CodingKeys.self)
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        let main = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .main)
        
        let wind = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .wind)
        
        name = try container.decode(String.self, forKey: .name)
        
        temp = try main.decode(Double.self, forKey: .temp)
        
        humidity = try main.decode(Int.self, forKey: .humidity)
        
        windSpeed = try wind.decode(Double.self, forKey: .speed)
        
        //let humidity = try values.decode(Double.self, forKey: .humidity)
        
        //main = MainWeather(temp: tempreature)
        
    }
    
}
