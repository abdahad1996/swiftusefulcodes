//
//  WeatherService.swift
//  WeatherApp
//
//

import Foundation

import Alamofire

class APIClient {
    
    static let shared: APIClient = APIClient()
    
    let apiKey = "0f5b2794af8ec541d56cb8904c601fa2"
    
    func getWeatherDataURL(lat: String, long: String) -> String {
        
        return "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(long)&APPID=\(apiKey)"
        
    }
 
}

