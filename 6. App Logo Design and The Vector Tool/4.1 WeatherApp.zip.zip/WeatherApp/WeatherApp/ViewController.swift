//
//  ViewController.swift
//  WeatherApp
//
//

import UIKit

import Alamofire

import SwiftyJSON

import CoreLocation

class ViewController: UIViewController {
    
    @IBOutlet weak var weatherIcon: UIImageView!
    
    @IBOutlet weak var currentTempLabel: UILabel!
    
    @IBOutlet weak var humidityLabel: UILabel!
    
    @IBOutlet weak var windSpeedLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        locationManager.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestLocation()
        
        //getweatherData(lat: "35", long: "139")
        
    }

    //swifty json
    func getweatherData(lat: String, long: String) {
        
        AF.request(APIClient.shared.getWeatherDataURL(lat: lat, long: long)).responseJSON { [weak self] response in
            
            guard let strongSelf = self else { return }
            
            print(response)
            
            if let json = response.result.value as? [String: Any] {
                
                print(json)
                
                let jsonData = JSON(json)
                
                if let humidity = jsonData["main"]["humidity"].int {
                    
                    DispatchQueue.main.async {
                        
                        strongSelf.humidityLabel.text = "\(humidity)"
                        
                    }
                    
                }
                
                if let temp = jsonData["main"]["temp"].double {
                    
                    DispatchQueue.main.async {
                        
                        strongSelf.currentTempLabel.text = "\(Int(temp))"
                        
                    }
                    
                }
                
                if let windSpeed = jsonData["wind"]["speed"].double {
                    
                    DispatchQueue.main.async {
                        
                        strongSelf.windSpeedLabel.text = "\(windSpeed)"
                        
                    }
                    
                }
            
                if let name = jsonData["name"].string {
                    
                    DispatchQueue.main.async {
                        
                        strongSelf.nameLabel.text = "\(name)"
                        
                    }
                    
                }
                
            }
        
        }
        
    }
    
    //manual
    func getweatherManual(lat: String, long: String) {
        
        AF.request(APIClient.shared.getWeatherDataURL(lat: lat, long: long)).responseJSON { response in
            
            if let json = response.result.value as? [String: Any] {
                
                if let main = json["main"] as? [String: Any] {
                    
                    if let humidity = main["humidity"] as? Int {
                        
                        print("the humidity is \(humidity)")
                        
                    }
                    
                }
                
            }
            
        }
        
    }
    
    //codable
    func getweatherCodable(lat: String, long: String) {
    
        /*
        let headers: HTTPHeaders = [
            "Accept": "application/json"
        ]
        
        let parameters: Parameters = [:]
        
        let url = APIClient.shared.getWeatherDataURL(lat: lat, long: long)
        
        guard let realURL = URL(string: url) else { return }
        
        AF.request(realURL, method: HTTPMethod.get, parameters: parameters, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
            
            if let jsonData = response.result.value as? [String: Any] {
                
                print(jsonData)
                
            }
            
        }
        */
        
        
        AF.request(APIClient.shared.getWeatherDataURL(lat: lat, long: long)).responseJSON { response in
            
            if let jsonData = response.data {
                
                do {
                
                    let weatherObject = try JSONDecoder().decode(WeatherModel.self, from: jsonData)
                    
                    print("name is \(weatherObject.name) and temp is \(weatherObject.temp) and humidity is \(weatherObject.humidity) and wind speed is \(weatherObject.windSpeed)")
                    
                } catch let error as NSError {
                    
                    print(error.localizedDescription)
                    
                }
                
            }
            
        }
        
    }
    
    //urlsession
    func getWeatherWithURLSession(lat: String, long: String) {
        
        let apiKey = APIClient.shared.apiKey
        
        if var urlComponents = URLComponents(string: "https://api.openweathermap.org/data/2.5/weather") {
            urlComponents.query = "lat=\(lat)&lon=\(long)&APPID=\(apiKey)"
            
            guard let url = urlComponents.url else { return }
            
            var request = URLRequest(url: url)
            
            request.httpMethod = "GET"
            
            request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Accept")
            
            let config = URLSessionConfiguration.default
            
            let session = URLSession(configuration: config)
            
            // make the request
            let task = session.dataTask(with: request) { (data, response, error) in
                
                if let error = error {
                    
                    print(error.localizedDescription)
                    
                }
                
                guard let data = data else { return }
                
                
                
                do {
                    
                    guard let weatherData = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                        
                            print("error trying to convert data to JSON")
                        
                            return
                        
                    }
                    
                    print(weatherData)
                    
                } catch  {
                    
                    print("error trying to convert data to JSON")
                    
                    return
                    
                }
                
            }
            
            task.resume()
            
        }
        
        /*
        guard let weatherURL = URL(string: APIClient.shared.getWeatherDataURL(lat: lat, long: long)) else { return }
        
        URLSession.shared.dataTask(with: weatherURL) { (data, response, error) in
            
            guard let data = data else { return }
            
            do {
                
                let decoder = JSONDecoder()
                
                let weatherObject = try decoder.decode(WeatherModel.self, from: data)
                
                print("name is \(weatherObject.name) and temp is \(weatherObject.temp)")
                
            } catch let err {
                
                print("Err", err)
                
            }
            
        }.resume()
        */
        
    }
    
    
}

extension ViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        print("in")
        
        if let location = locations.first {
            
            let latitude = String(location.coordinate.latitude)
            
            let longitude = String(location.coordinate.longitude)
            
            print(latitude)
            
            print(longitude)
            
            getweatherCodable(lat: latitude, long: longitude)
            
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        switch status {
            
        case .notDetermined:
            
            locationManager.requestWhenInUseAuthorization()
            
        case .authorizedAlways, .authorizedWhenInUse:
            
            locationManager.requestLocation()
            
        case .restricted, .denied:
            
            let alertController = UIAlertController(title: "Location Access Disabled", message: "In order to get weather please allow location access", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            
            alertController.addAction(cancelAction)
            
            let openAction = UIAlertAction(title: "Open Settings", style: .default, handler: { (action) in
                
                if let url = NSURL(string: UIApplication.openSettingsURLString) {
                    
                    UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                    
                }
                
            })
            
            alertController.addAction(openAction)
            
            present(alertController, animated: true, completion: nil)
            
            break
            
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        print(error.localizedDescription)
        
    }
    
}

