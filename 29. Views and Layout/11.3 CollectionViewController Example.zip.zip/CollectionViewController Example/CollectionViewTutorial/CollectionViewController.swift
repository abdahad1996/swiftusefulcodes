//
//  CollectionViewController.swift
//  CollectionViewTutorial
//
//

import UIKit

private let reuseIdentifier = "PhotoCollectionViewCell"

class CollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    let data: [UIImage] = [UIImage(named: "image1")!, UIImage(named: "image2")!, UIImage(named: "image3")!, UIImage(named: "image4")!]

    override func viewDidLoad() {
        super.viewDidLoad()

        

    }

    // MARK: UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return data.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! PhotoCollectionViewCell
    
        cell.photoImageView.image = data[indexPath.row]
    
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let itemsPerRow: CGFloat = 3
        
        let collectionViewWidth: CGFloat = collectionView.frame.width
        
        let widthPerItem: CGFloat = collectionViewWidth / itemsPerRow
        
        return CGSize(width: widthPerItem, height: widthPerItem)
        
    }

}
