//
//  ViewController.swift
//  CollectionViewTutorial
//
//

import UIKit

class ViewController: UIViewController {
    
    let data: [UIImage] = [UIImage(named: "image1")!, UIImage(named: "image2")!, UIImage(named: "image3")!, UIImage(named: "image4")!]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }


}

