//
//  PhotoCollectionViewCell.swift
//  CollectionViewTutorial
//
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    
}
