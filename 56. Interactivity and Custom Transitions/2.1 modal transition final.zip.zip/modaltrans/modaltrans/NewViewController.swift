//
//  NewViewController.swift
//  modaltrans
//
//

import UIKit

class NewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func hideNewVC(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
        
    }
    

}
