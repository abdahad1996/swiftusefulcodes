//
//  ImageCollectionViewCell.swift
//  PhotoAlbulm
//
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
    
}
