//: [Previous](@previous)
/*:
 ## Adapter Design Pattern
 The adapter is a structural design pattern allows entities that would otherwise be incompatible with one another to be linked.
*/

struct OldLocation {
    
    var xPosition: Double
    
    var yPosition: Double
    
}

struct NewLocation {
    
    let oldLocation: OldLocation
    
    var latitude: Double {
        
        return oldLocation.xPosition
        
    }
    
    var longitude: Double {
        
        return oldLocation.yPosition
        
    }
    
}

let oldLocation = OldLocation(xPosition: 23.0, yPosition: 34.2)

let newLocation = NewLocation(oldLocation: oldLocation)

//: [Next](@next)
