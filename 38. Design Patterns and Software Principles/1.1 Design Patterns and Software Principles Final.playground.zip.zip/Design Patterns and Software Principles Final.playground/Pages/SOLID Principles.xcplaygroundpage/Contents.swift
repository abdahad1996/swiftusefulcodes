/*:
 ## SOLID Principles
 
 The SOLID design principles encourage us to create more maintainable, understandable and flexible software.
 
 ### Single Responsibility Principle
 Entities should have one responsibility.
 
 ### Open-Closed Principle
 Entities should be open to extension but closed to modification.
 
 ### Liskov Substitution Principle
 If class A is a subtype of class B, then we should be able to replace B with A without disrupting the behaviour of our program.
 
 ### Interface Segregation
 Entities should not use interfaces they won't completely use. Large interfaces should be split into smaller ones.
 
 ### Dependency Inversion
 High level modules should not depend on low level modules, both should depend on abstractions.
 
*/
//Single Responsibility

class User {
    
    var name: String
    
    var profileName: String
    
    init(name: String, profileName: String) {
        
        self.name = name
        
        self.profileName = profileName
        
    }
    
    func changeName(to name: String) {
        
        self.name = name
    }
    
    func changeProfileName(to profileName: String) {
        
        self.profileName = profileName
    }
    
}

struct Account {
    
    var user: User
    
    init(user: User) {
        
        self.user = user
        
    }
    
    func createAccount() {
        
        print("account created")
        
    }
    
    func loginAccount() {
        
        print("logged into account")
        
    }
    
    func logoutAccount() {
        
        print("logged out of account")
        
    }
    
}

//Open-Closed Principle

class Guitar {
    
    var brandName: String
    
    var model: String
    
    init(brandName: String, model: String) {
        
        self.brandName = brandName
        
        self.model = model
        
    }
    
}

class FlameGuitar: Guitar {
    
    var flame: String = "Red"
    
}

protocol Instrument {
    
    var brandName: String { get set }
    
    var model: String { get set }
    
}

class BassGuitar: Instrument {
    
    var brandName: String
    
    var model: String
    
    init(brandName: String, model: String) {
        
        self.brandName = brandName
        
        self.model = model
        
    }
    
}

class WaterGuitar: Instrument {
    
    var brandName: String
    
    var model: String
    
    var waterVolume: Int
    
    init(brandName: String, model: String, waterVolume: Int) {
        
        self.brandName = brandName
        
        self.model = model
        
        self.waterVolume = waterVolume
        
    }
    
}

// Liskov Substitution Principle

protocol Polygon {
    
    var area: Float { get }
    
}

class Rectangle: Polygon {
    
    var width: Float = 0

    var length: Float = 0
    
    init(length: Float, width: Float) {
        
        self.length = length
        
        self.width = width
        
    }
    
    var area: Float {
        return width * length
    }
    
}

class Square: Polygon {
    
    var side: Float = 0
    
    init(side: Float) {
        
        self.side = side
        
    }
    
    var area: Float {
        
        return side * side
        
    }
    
}

func printArea(ofPolygon polygon: Polygon) {
    
    print(polygon.area)
    
}

let rectangle = Rectangle(length: 10, width: 2)

printArea(ofPolygon: rectangle)

let square = Square(side: 2)

printArea(ofPolygon: square)

//Interface Segregation

protocol Vehicle {
    
    func accelerate()
    
}

protocol Engine {
    
    func turnEngineOn()
    
}

class MotorCar: Vehicle, Engine {
    
    func turnEngineOn() {
        
        print("engine on!")
        
    }
    
    func accelerate() {
        
        print("going faster")
        
    }
    
}

class HorseDrawnCarriage: Vehicle {
    
    func accelerate() {
        
        print("going faster")
        
    }
    
}

//Dependency Inversion

protocol CloudService {
    
    func fetchData(url: String) -> [String]
    
}

struct FirebaseService: CloudService {
    
    func observeSingleEvent(forRef: String) -> [String] {
        
        return ["Post"]
        
    }
    
    func fetchData(url: String) -> [String] {
        
        return observeSingleEvent(forRef: url)
        
    }
    
}

struct ParseService: CloudService {
    
    func fetchData(url: String) -> [String] {
        
        return ["Post"]
        
    }
    
}

class UserFeed {
    
    private let data: CloudService
    
    init(data: CloudService) {
        
        self.data = data
        
    }
    
    func getUserFeedData(url: String) {
        
        data.fetchData(url: url)
        
    }
    
}

let parseService = ParseService()

let userFeedService = UserFeed(data: parseService)

userFeedService.getUserFeedData(url: "url")










