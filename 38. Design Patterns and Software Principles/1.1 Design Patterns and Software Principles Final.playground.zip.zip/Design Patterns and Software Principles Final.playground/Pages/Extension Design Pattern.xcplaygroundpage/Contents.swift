//: [Previous](@previous)
/*:
 ## Extensions Design Pattern
 Extensions allow you to add new functionality to an existing entity.
*/
import Foundation

extension Double {
    
    func toCurrency() -> String? {
        
        let currencyFormatter = NumberFormatter()
        
        currencyFormatter.numberStyle = .currency
        
        return currencyFormatter.string(from: NSNumber(value: self))
        
    }
    
}

let amount = 23.09

if let currency = amount.toCurrency() {
    
    print(currency)
    
}
//: [Next](@next)
