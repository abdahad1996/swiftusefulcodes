/*:
 # Design Patterns and Software Principles
 
 *A designer knows he has achieved perfection not when there is nothing left to add but when there is nothing left to take away.* - Antoine de Saint-Expupery
 
 ![Design Patterns](design-patterns.jpg)
 
 **NOTE: I will be using the term "entity" to loosely refer to a class, structure or object**
 
 Design patterns are reusable solutions to common problems in software design. There are broadly three types of design patterns according to the Gang of Four's book `Design Patterns: Elements of Reusable Object-Oriented Software`:
 
 * **Creational** - deal with entity creation e.g Singleton and Factory design patterns.
 * **Structural** - identify a simple way to realize relationships between entities. e.g Adapter design pattern.
 * **Behavioural** - identify common communication patterns between entities e.g Observor design pattern
 
 `Delegation` and `Extensions` are often referred to as design patterns in some circles. They are design patterns in the sense they are used as the basis for many other design patterns to work. For example, the Decorator design pattern relies on delegation to work.
 
 MVC and MVVM are often referred to as design patterns as well but it is often more correct to refer to them as architectural design patterns which is distinct from the three design pattern types defined by the Gang of Four. The evidence of this is found in the very book that made MVC famous, `Pattern-Oriented Software Architecture (POSA) (1996)` which clearly identifies MVC as an architectural design pattern.
 
 Software principles are a set of guidelines that make our code easier to maintain, test, understand and manage as it grows in size. Examples of software principles include the DRY (Do Not Repeat Yourself) principle and the SOLID principle which we will learn about in this part of the course.
 
*/



//: [Next](@next)
