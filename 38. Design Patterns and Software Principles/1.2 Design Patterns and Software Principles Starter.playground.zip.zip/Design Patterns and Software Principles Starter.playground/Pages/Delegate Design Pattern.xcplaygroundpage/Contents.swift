//: [Previous](@previous)
/*:
 ## Delegation Design Pattern
 According to Apple, "Delegation is a simple and powerful pattern in which one object in a program acts on behalf of, or in coordination with, another object". A delegation design pattern *hands over responsibility* to some other entity.
 
*/
struct Product {
    
    var name: String
    
}

struct OnlineShop {
    
    private(set) var shopName: String
    
    private(set) var products = [Product]()
    
    init(shopName: String) {
        
        self.shopName = shopName
        
    }
    
    mutating func add(product: Product) {
        
        self.products.append(product)
        
    }
    
    func sendAllProducts() {
        
        for product in products {
            
            send(product: product)
            
        }
        
    }
    
    private func send(product: Product) {
        
        print("\(product.name) sent!")
        
    }
    
}

var onlineShop = OnlineShop(shopName: "Amazon")

onlineShop.add(product: Product(name: "MacBook Pro"))

onlineShop.add(product: Product(name: "Apple Watch"))

onlineShop.add(product: Product(name: "iMac"))

onlineShop.sendAllProducts()



//: [Next](@next)
