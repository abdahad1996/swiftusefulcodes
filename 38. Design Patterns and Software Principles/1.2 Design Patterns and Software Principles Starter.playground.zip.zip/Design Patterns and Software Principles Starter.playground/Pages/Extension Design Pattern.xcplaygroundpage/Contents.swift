//: [Previous](@previous)
/*:
 ## Extensions Design Pattern
 Extensions allow you to add new functionality to an existing entity.
*/
import Foundation

func convertToCurrency(_ amount: Double) -> String? {
    
    let currencyFormatter = NumberFormatter()
    
    currencyFormatter.numberStyle = .currency
    
    return currencyFormatter.string(from: NSNumber(value: amount))
    
}
//: [Next](@next)
