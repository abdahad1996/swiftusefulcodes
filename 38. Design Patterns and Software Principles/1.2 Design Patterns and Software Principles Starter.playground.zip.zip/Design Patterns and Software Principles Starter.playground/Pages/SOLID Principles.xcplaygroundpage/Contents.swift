/*:
 ## SOLID Principles
 
 The SOLID design principles encourage us to create more maintainable, understandable and flexible software.
 
 ### Single Responsibility Principle
 Entities should have one responsibility.
 
 ### Open-Closed Principle
 Entities should be open to extension but closed to modification.
 
 ### Liskov Substitution Principle
 If class A is a subtype of class B, then we should be able to replace B with A without disrupting the behaviour of our program.
 
 ### Interface Segregation
 Entities should not use interfaces they won't completely use. Large interfaces should be split into smaller ones.
 
 ### Dependency Inversion
 High level modules should not depend on low level modules, both should depend on abstractions.
 
*/
//Single Responsibility

struct User {
    
    var name: String
    
    var profileName: String
    
    mutating func changeName(to name: String) {
        
        self.name = name
    }
    
    mutating func changeProfileName(to profileName: String) {
        
        self.profileName = profileName
    }
    
    func createAccount() {
        
        print("account created")
        
    }
    
    func loginAccount() {
        
        print("logged into account")
        
    }
    
    func logoutAccount() {
        
        print("logged out of account")
        
    }
    
}

//Open-Closed Principle

class Guitar {
    
    var brandName: String
    
    var model: String
    
    init(brandName: String, model: String) {
        
        self.brandName = brandName
        
        self.model = model
        
    }
    
}

// Liskov Substitution Principle

class Rectangle {
    
    var width: Float = 0

    var length: Float = 0
    
    var area: Float {
        return width * length
    }
    
}

//Interface Segregation

class Vehicle {
    
    func turnEngineOn() {
        
        fatalError()
        
    }
    
    func accelerate() {
        
        fatalError()
        
    }
    
}

class MotorCar: Vehicle {
    
    override func turnEngineOn() {
        
        print("engine on!")
        
    }
    
    override func accelerate() {
        
        print("going faster")
        
    }
    
}

//Dependency Inversion

struct FirebaseService {
    
    func observeSingleEvent(forRef: String) -> [String] {
        
        return ["Post"]
        
    }
    
}

class UserFeed {
    
    private let data: FirebaseService
    
    init(data: FirebaseService) {
        
        self.data = data
        
    }
    
    func getUserFeedData(url: String) {
        
        data.observeSingleEvent(forRef: "ref")
        
    }
    
}










