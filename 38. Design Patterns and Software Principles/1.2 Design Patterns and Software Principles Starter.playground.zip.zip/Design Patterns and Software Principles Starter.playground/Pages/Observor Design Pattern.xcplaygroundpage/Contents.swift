//: [Previous](@previous)
/*:
 ## Observor Design Pattern
 The observor design pattern is used to inform other entities of changes to its state.
*/
enum Team: String {
    
    case barcelona, juventus
    
}

class Player {
    
    var name: String
    
    let team: Team
    
    var goalCount = 0
    
    init(name: String, team: Team) {
        
        self.name = name
        
        self.team = team
        
    }
    
    func didScore() {
        
        goalCount += 1
        
    }
    
}

class Game {
    
    var players = [Player]()
    
    init(players: [Player]) {
        
        print("game started")
        
        self.players = players
        
    }
    
    func scoreUpdate() {
        
        var barcelonaScore = 0
        
        var juventusScore = 0
        
        for player in players {
            
            switch player.team {
                
            case .barcelona:
                
                barcelonaScore += player.goalCount
                
            case .juventus:
                
                juventusScore += player.goalCount
                
            }
            
        }
        
        print("Barcelona \(barcelonaScore) - Juventus \(juventusScore)")
        
    }
    
}

let messi = Player(name: "Messi", team: .barcelona)

let ronaldo = Player(name: "Ronaldo", team: .juventus)

let game = Game(players: [messi, ronaldo])

messi.didScore()

ronaldo.didScore()

messi.didScore()

ronaldo.didScore()

game.scoreUpdate()
//: [Next](@next)
