//: [Previous](@previous)
/*:
 ## Adapter Design Pattern
 The adapter is a structural design pattern allows entities that would otherwise be incompatible with one another to be linked through an interface.
*/

struct OldLocation {
    
    var xPosition: Double
    
    var yPosition: Double
    
}

let oldLocation = OldLocation(xPosition: 23.0, yPosition: 34.2)

//: [Next](@next)
