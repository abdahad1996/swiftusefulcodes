//: [Previous](@previous)
/*:
 ## Factory Design Pattern
 The factory design pattern is used to encapsulate the implementation details of creating entities which adhere to a common interface.
*/

protocol Fruit {
    
    var name: String { get }
    
}

struct Apple: Fruit {
    
    let name = "Apple"
    
}

struct Orange: Fruit {
    
    let name = "Orange"
    
}
//: [Next](@next)
