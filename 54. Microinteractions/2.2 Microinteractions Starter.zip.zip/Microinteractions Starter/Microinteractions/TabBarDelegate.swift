//
//  TabBarDelegate.swift
//  Microinteractions
//
//

import Foundation

import UIKit

class TabBarDelegate: NSObject, UITabBarControllerDelegate {
    
    
    
}
