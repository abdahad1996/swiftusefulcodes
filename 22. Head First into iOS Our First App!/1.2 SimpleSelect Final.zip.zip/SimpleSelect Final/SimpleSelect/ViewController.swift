//
//  ViewController.swift
//  SimpleSelect
//
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var itemLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func roseButtonDidTouch(_ sender: Any) {
        
        itemLabel.text = "Rose"
        
    }
    
    @IBAction func lemonsButtonDidTouch(_ sender: Any) {
        
        itemLabel.text = "Lemons"
        
    }
    
    @IBAction func applesButtonDidtouch(_ sender: Any) {
        
        itemLabel.text = "Apples"
        
    }
    
    @IBAction func eggsButtonDidTouch(_ sender: Any) {
        
        itemLabel.text = "Eggs"
        
    }
    
    
}

