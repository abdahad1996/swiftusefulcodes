//
//  ViewController.swift
//  SimpleSelect
//
//  Created by Gwinyai on 4/4/2019.
//  Copyright © 2019 Gwinyai. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

