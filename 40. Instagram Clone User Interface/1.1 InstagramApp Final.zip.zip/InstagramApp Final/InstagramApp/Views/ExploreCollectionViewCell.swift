//
//  ExploreCollectionViewCell.swift
//  InstagramApp
//
//  Created by Gwinyai on 19/10/2018.
//  Copyright © 2018 Gwinyai Nyatsoka. All rights reserved.
//

import UIKit

class ExploreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var exploreImage: UIImageView!
    
}
