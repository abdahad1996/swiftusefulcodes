//
//  PhotoCollectionViewCell.swift
//  InstagramApp
//
//  Created by Gwinyai on 28/10/2018.
//  Copyright © 2018 Gwinyai Nyatsoka. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoImageView: UIImageView!
    
}
