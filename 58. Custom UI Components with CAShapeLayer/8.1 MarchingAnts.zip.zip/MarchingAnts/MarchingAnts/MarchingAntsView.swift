//
//  MarchingAntsView.swift
//  MarchingAnts
//
//

import UIKit

class MarchingAntsView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        
        let antsLoader = CAShapeLayer()
        
        let lineWidth: CGFloat = 6.0
        
        antsLoader.lineWidth = lineWidth
        
        antsLoader.strokeColor = UIColor.purple.cgColor
        
        let loaderWidth = min(bounds.width, bounds.height)
        
        antsLoader.path = UIBezierPath(ovalIn: CGRect(x: lineWidth / 2, y: lineWidth / 2, width: loaderWidth - lineWidth, height: loaderWidth - lineWidth)).cgPath
        
        antsLoader.frame = CGRect(x: 0, y: 0, width: loaderWidth, height: loaderWidth)
        
        let radius = (loaderWidth - lineWidth) / 2
        
        let cicumference = 2 * CGFloat(Double.pi) * radius
        
        let phaseSize = cicumference / 200
        
        antsLoader.lineDashPattern = [NSNumber(value: Float(phaseSize))]
        
        antsLoader.fillColor = nil
        
        layer.addSublayer(antsLoader)
        
        let lineDashPhaseAnimation = CABasicAnimation(keyPath: "transform")
        
        lineDashPhaseAnimation.byValue = CATransform3DMakeRotation(CGFloat(Double.pi), 0.0, 0.0, 1.0)
        
        lineDashPhaseAnimation.duration = 10.0
        
        lineDashPhaseAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        lineDashPhaseAnimation.repeatCount = .greatestFiniteMagnitude
        
        antsLoader.add(lineDashPhaseAnimation, forKey: nil)
        
        
        
    }

}
