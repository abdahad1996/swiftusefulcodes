//
//  ViewController.swift
//  MarchingAnts
//
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var loadingText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        startLoading()
        
    }

    func startLoading() {
        
        let antsLoader = CAShapeLayer()
        
        let lineWidth: CGFloat = 6.0
        
        antsLoader.lineWidth = lineWidth
        
        antsLoader.strokeColor = UIColor.purple.cgColor
        
        antsLoader.path = UIBezierPath(ovalIn: CGRect(x: lineWidth / 2, y: lineWidth / 2, width: 200 - lineWidth, height: 200 - lineWidth)).cgPath
        
        antsLoader.frame = CGRect(x: view.frame.midX - 100, y: view.frame.midY - 100, width: 200, height: 200)
        
        let radius = (200 - lineWidth) / 2
        
        let cicumference = 2 * CGFloat(Double.pi) * radius
        
        let phaseSize = cicumference / 200
        
        antsLoader.lineDashPattern = [NSNumber(value: Float(phaseSize))]
        
        antsLoader.fillColor = nil
        
        view.layer.addSublayer(antsLoader)
        
        let lineDashPhaseAnimation = CABasicAnimation(keyPath: "transform")
        
        lineDashPhaseAnimation.byValue = CATransform3DMakeRotation(CGFloat(Double.pi), 0.0, 0.0, 1.0)
        
        lineDashPhaseAnimation.duration = 10.0
        
        lineDashPhaseAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        lineDashPhaseAnimation.repeatCount = .greatestFiniteMagnitude
        
        antsLoader.add(lineDashPhaseAnimation, forKey: "lineDashPhaseAnimation")
        
        let fadeInAndOutAnimation = CABasicAnimation(keyPath: "opacity")
        
        fadeInAndOutAnimation.fromValue = 1.0
        
        fadeInAndOutAnimation.toValue = 0.0
        
        fadeInAndOutAnimation.duration = 1.0
        
        fadeInAndOutAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        
        fadeInAndOutAnimation.repeatCount = .greatestFiniteMagnitude
        
        fadeInAndOutAnimation.autoreverses = true
        
        loadingText.layer.add(fadeInAndOutAnimation, forKey: nil)
        
    }


}

