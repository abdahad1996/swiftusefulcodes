//
//  ViewController.swift
//  Snapsie
//
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var capturedPhotoImageView: UIImageView!
    
    @IBOutlet weak var takePhotoButton: UIButton!
    
    private let imagePicker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        imagePicker.delegate = self
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        takePhotoButton.layer.cornerRadius = takePhotoButton.frame.height / 2
        
    }
    
    @IBAction func takePhotoButtonDidTouch(_ sender: Any) {
        
        imagePicker.allowsEditing = true
        
        imagePicker.sourceType = .camera
        
        present(imagePicker, animated: true, completion: nil)
        
    }
    
}

extension ViewController: UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            
            capturedPhotoImageView.image = pickedImage
            
        }
        
        dismiss(animated: true, completion: nil)
        
    }
    
}

