import UIKit

import PlaygroundSupport

let v = UIViewController()

PlaygroundPage.current.liveView = v

//START YOUR CODE FROM HERE


func showAlert(title: String, message: String) {
    
    let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
    
    let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
        
        alert.dismiss(animated: true, completion: nil)
        
    }
    
    alert.addAction(okAction)
    
    v.present(alert, animated: true, completion: nil)
    
}

func showOption(message: String, correctOption: Bool) {
    
    let alert = UIAlertController(title: "Choose a Path", message: message, preferredStyle: .alert)
    
    let yesAction = UIAlertAction(title: "Yes", style: .default) { (action) in
        
        alert.dismiss(animated: true, completion: nil)
        
        if correctOption == true {
            
            //nextChoice()
            
        }
        else {
            
            //gameOver()
            
        }
        
    }
    
    let noAction = UIAlertAction(title: "No", style: .default) { (action) in
        
        alert.dismiss(animated: true, completion: nil)
        
        if correctOption == false {
            
            //nextChoice()
            
        }
        else {
            
            //gameOver()
            
        }
        
    }
    
    alert.addAction(yesAction)
    
    alert.addAction(noAction)
    
    v.present(alert, animated: true, completion: nil)
    
}
