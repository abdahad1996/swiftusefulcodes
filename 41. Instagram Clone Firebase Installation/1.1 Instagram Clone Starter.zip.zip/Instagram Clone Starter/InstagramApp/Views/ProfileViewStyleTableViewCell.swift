//
//  ProfileViewStyleTableViewCell.swift
//  InstagramApp
//
//  Created by Gwinyai on 20/1/2019.
//  Copyright © 2019 Gwinyai Nyatsoka. All rights reserved.
//

import UIKit

class ProfileViewStyleTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func gridStyleButtonDidTouch(_ sender: Any) {
    }
    
    @IBAction func listStyleButtonDidTouch(_ sender: Any) {
    }
    
}
