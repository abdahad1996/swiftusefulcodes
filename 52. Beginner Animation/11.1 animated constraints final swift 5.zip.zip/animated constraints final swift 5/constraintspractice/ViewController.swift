//
//  ViewController.swift
//  constraintspractice
//
/*
 MIT License
 
 Copyright (c) 2019 Gwinyai Nyatsoka
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var topMenuConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var redButton: UIButton!
    
    @IBOutlet weak var orangeButton: UIButton!
    
    @IBOutlet weak var purpleButton: UIButton!
    
    @IBOutlet weak var toggleButton: UIButton!
    
    @IBOutlet weak var menuView: UIView!
    
    var isMenuOpen: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let statusBarHeight = UIApplication.shared.statusBarFrame.height
        
        topMenuConstraint.constant = -menuView.frame.size.height + CGFloat(40) + statusBarHeight
        
        menuView.layer.shadowOpacity = 0.4
        
        menuView.layer.shadowColor = UIColor.black.cgColor
        
        menuView.layer.shadowOffset = CGSize.zero
        
        menuView.layer.shadowRadius = CGFloat(15.0)
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        redButton.layer.cornerRadius = redButton.frame.size.width / 2
        
        orangeButton.layer.cornerRadius = orangeButton.frame.size.width / 2
        
        purpleButton.layer.cornerRadius = purpleButton.frame.size.width / 2
        
    }

    
    @IBAction func redButtonDidTouch(_ sender: Any) {
        
        view.backgroundColor = UIColor.red
        
    }
    
    
    @IBAction func orangeButtonDidTouch(_ sender: Any) {
        
        view.backgroundColor = UIColor.orange
        
    }
    
    @IBAction func purpleButtonDidTouch(_ sender: Any) {
        
        view.backgroundColor = UIColor.purple
        
    }
    
    func closeMenu() {
        
        let statusBarHeight = UIApplication.shared.statusBarFrame.height
        
        UIView.animate(withDuration: 0.7, delay: 0, options: .curveEaseOut, animations: {
            
            self.topMenuConstraint.constant = -self.menuView.frame.size.height + CGFloat(40) + statusBarHeight
            
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        
    }
    
    func openMenu() {
        
        UIView.animate(withDuration: 0.7, delay: 0, options: .curveEaseOut, animations: {
            
            self.topMenuConstraint.constant = CGFloat(0)
            
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
    }
    
    @IBAction func toggleButtonDidTouch(_ sender: UIButton) {
        
        if isMenuOpen {
            
            sender.setTitle("Open", for: .normal)
            
            isMenuOpen = false
            
            closeMenu()
            
        }
        else {
            
            sender.setTitle("Close", for: .normal)
            
            isMenuOpen = true
            
            openMenu()
            
        }
        
    }
    
    
}

